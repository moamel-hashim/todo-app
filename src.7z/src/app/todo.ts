export class Todo {
  id:number = 0;
  name:string = '';
}

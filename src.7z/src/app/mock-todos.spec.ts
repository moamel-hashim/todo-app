import { MockTodos } from './mock-todos';

describe('MockTodos', () => {
  it('should create an instance', () => {
    expect(new MockTodos()).toBeTruthy();
  });
});
